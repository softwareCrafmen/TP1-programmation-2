﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Char;

namespace Utilitaires
{
    /// <summary>
    /// Liste de méthode qui facilite la programmation
    /// </summary>
    public static class Util
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_indice"></param>
        public static void RemoveAtSansOrdre<T>(this List<T> p_v, int p_indice)
        {
            p_v[p_indice] = p_v[p_v.Count - 1];
            p_v.RemoveAt(p_v.Count - 1);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_valeur"></param>
        /// <returns></returns>
        public static bool RemoveSansOrdre<T>(this List<T> p_v, T p_valeur)
        {
            int indiceValeur = p_v.IndexOf(p_valeur);

            if (indiceValeur == -1)
                return false;

            p_v[indiceValeur] = p_v[p_v.Count - 1];
            p_v.RemoveAt(p_v.Count - 1);
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_prédicat"></param>
        /// <returns></returns>
        public static int RemoveAllSansOrdre<T>(this List<T> p_v, Predicate<T> p_prédicat)
        {
            int nbRetraits = 0;

            for (int i = 0; i != p_v.Count - nbRetraits;)
            {
                if (!p_prédicat(p_v[i]))
                    ++i;
                else
                {
                    ++nbRetraits;
                    p_v[i] = p_v[p_v.Count - nbRetraits];
                }


            }
            p_v.RemoveRange(p_v.Count - nbRetraits, nbRetraits);
            return nbRetraits;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_indice"></param>
        public static void RemoveAtEnOrdre<T>(this List<T> p_v, int p_indice)
        {
            p_v.RemoveAt(p_indice);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_valeur"></param>
        /// <returns></returns>
        public static bool RemoveEnOrdre<T>(this List<T> p_v, T p_valeur)
        {
            int indiceValeur = p_v.IndexOf(p_valeur);

            if (indiceValeur == -1)
                return false;

            p_v.RemoveAt(indiceValeur);
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="p_v"></param>
        /// <param name="p_prédicat"></param>
        /// <returns></returns>
        public static int RemoveAllEnOrdre<T>(this List<T> p_v, Predicate<T> p_prédicat)
        {
            return p_v.RemoveAll(p_prédicat);
        }

//-----------------------------Lire Int32---------------------------------

/// <summary>
/// Lie et vérifie un nombre entier.
/// </summary>
/// <param name="p_question">question posée</param>
/// <returns>nombre entier lue</returns>
public static int LireInt32(string p_question)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for(;;)
            {
                Write(p_question);
                /**/
                if (Int32.TryParse(ReadLine(), out nombre)) break;
                /**/
                WriteLine("*** Veuillez entrer un simple nombre entier.");
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre entier positif.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <returns>nombre entier positif lue</returns>
        public static int LireInt32Positif(string p_question)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireInt32(p_question);
                /**/
                if (nombre >= 0) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre entier positif.");
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre entier avec un minimum.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <param name="p_minimum">nombre entier minimum</param>
        /// <returns>nombre entier avec un minimum lue/returns>
        public static int LireInt32AvecMinimum(string p_question, int p_minimum)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireInt32(p_question);
                /**/
                if (nombre >= p_minimum) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre entier supérieur ou égal à {0}.",
                    p_minimum);
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre entier dans un intervalle.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <param name="p_minimum">nombre entier minimum</param>
        /// <param name="p_maximum">nombre entier maximum</param>
        /// <returns>nombre entier dans un intervalle lue</returns>
        public static int LireInt32DansIntervalle(string p_question, int p_minimum, int p_maximum)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireInt32(p_question);
                /**/
                if (p_minimum <= nombre && nombre <= p_maximum) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre entier entre {0} et {1}.",
                    p_minimum, p_maximum);
            }

            return nombre;
        }

        public static int LireInt32AvecMinimumOuSentinelle(string p_question, int p_minimum, int p_sentinelle)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireInt32(p_question);
                /**/
                if (nombre >= p_minimum || nombre == p_sentinelle) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre entier supérieur ou égal à {0}.",
                    p_minimum);
            }

            return nombre;
        }

        public static int LireInt32DansIntervalleOuSentinelle(string p_question, int p_minimum, int p_maximum, int p_sentinelle)
        {
            int nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireInt32(p_question);
                /**/
                if ((p_minimum <= nombre && nombre <= p_maximum) || nombre == p_sentinelle) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre entier entre {0} et {1}.",
                    p_minimum, p_maximum);
            }

            return nombre;
        }

        //-----------------------------Lire Double---------------------------------

        /// <summary>
        /// Lie et vérifie un nombre décimal.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <returns>nombre décimal lue</returns>
        public static double LireDouble(string p_question)
        {
            double nombre;  //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                Write(p_question);
                /**/
                if (Double.TryParse(ReadLine(), out nombre)) break;
                /**/
                WriteLine("*** Veuillez entrer un simple nombre entier.");
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre décimal positif.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <returns>nombre décimal positif lue</returns>
        public static double LireDoublePositif(string p_question)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if (nombre >= 0) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal positif.");
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre décimal avec un minimum.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <param name="p_minimum">nombre décimal minimum</param>
        /// <returns>nombre décimal avec un minimum lue</returns>
        public static double LireDoubleAvecMinimum(string p_question, double p_minimum)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if (nombre >= p_minimum) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal supérieur ou égal à {0}.",
                    p_minimum);
            }

            return nombre;
        }

        public static double LireDoubleAvecMinimumExclus(string p_question, double p_minimum)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if (nombre > p_minimum) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal supérieur à {0}.",
                    p_minimum);
            }

            return nombre;
        }

        /// <summary>
        /// Lie et vérifie un nombre décimal dans un intervalle.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <param name="p_minimum">nombre décimal minimum</param>
        /// <param name="p_maximum">nombre décimal maximum</param>
        /// <returns>nombre décimal dans un intervalle lue</returns>
        public static double LireDoubleDansIntervalle(string p_question, double p_minimum, double p_maximum)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if (p_minimum <= nombre && nombre <= p_maximum) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal entre {0} et {1}.",
                    p_minimum, p_maximum);
            }

            return nombre;
        }

        public static double LireDoubleAvecMinimumOuSentinelle(string p_question, double p_minimum, double p_sentinelle)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if (nombre >= p_minimum || nombre == p_sentinelle) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal supérieur ou égal à {0}.",
                    p_minimum);
            }

            return nombre;
        }

        public static double LireDoubleDansIntervalleOuSentinelle(string p_question, double p_minimum, double p_maximum, double p_sentinelle)
        {
            double nombre; //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                nombre = LireDouble(p_question);
                /**/
                if ((p_minimum <= nombre && nombre <= p_maximum) || nombre == p_sentinelle) break;
                /**/
                WriteLine("*** Veuillez entrer un nombre décimal entre {0} et {1}.",
                    p_minimum, p_maximum);
            }

            return nombre;
        }

        //-----------------------------Lire Char---------------------------------

        /// <summary>
        /// Lie et vérifie un caractère.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <returns>caractère(visible) lue</returns>
        public static char LireChar(string p_question)
        {
            char caractère;  //Contiendra le nombre provenant d'une lecture valide

            for (;;)
            {
                Write(p_question);
                /**/
                if (Char.TryParse(ReadLine(), out caractère)
                    &&
                    !IsControl(caractère)) break;
                /**/
                WriteLine("*** Veuillez entrer un, et un seul, caractère (ordinaire).");
            }

            return caractère;
        }

        //-----------------------------Lire String---------------------------------

        /// <summary>
        /// Lie et enlève les espaces avant et après le texte.
        /// </summary>
        /// <param name="p_question">question posée</param>
        /// <returns>texte lue</returns>
        public static string LireString(string p_question)
        {
            Write(p_question);
            return ReadLine().Trim();
        }

        /// <summary>
        /// Lie et vérifie un texte de taille contrôlée.
        /// </summary>
        /// <param name="p_question">qustion posée</param>
        /// <param name="p_lgMin">longueur minimal</param>
        /// <param name="p_lgMax">longueur maximal</param>
        /// <returns>texte de taille contrôlée lue</returns>
        public static string LireStringTailleContrôlée(string p_question, int p_lgMin, int p_lgMax)
        {
            string texte;

            for(;;)
            {
                Write(p_question);
                texte = ReadLine().Trim();
                /**/
                if (p_lgMin <= texte.Length && texte.Length <= p_lgMax) break;
                /**/
                WriteLine(
                    "*** Veuillez entrer un texte contenant entre {0} et {1} caratères.",
                    p_lgMin, p_lgMax);
            }

            return texte;
        }

        public static string LireStringTailleMaximum(string p_question, int p_lgMax)
        {
            string texte;

            for (;;)
            {
                Write(p_question);
                texte = ReadLine().Trim();
                /**/
                if (texte.Length <= p_lgMax) break;
                /**/
                WriteLine(
                    "*** Veuillez entrer un texte contenant au maximum {0} caratères.", p_lgMax);
            }

            return texte;
        }

        /// <summary>
        /// Lie et vérifie un texte non vide.
        /// </summary>
        /// <param name="p_question">qustion posée</param>
        /// <returns>texte non vide lue</returns>
        public static string LireStringNonVide(string p_question)
        {
            string texte;

            for (;;)
            {
                Write(p_question);
                texte = ReadLine().Trim();
                /**/
                if (texte.Length > 0) break;
                /**/
                WriteLine(
                    "*** Veuillez entrer un texte non vide.");
            }

            return texte;
        }

        public static string LireStringNonVideTailleMaximum(string p_question, int p_lgMax)
        {
            string texte;

            for (;;)
            {
                Write(p_question);
                texte = ReadLine().Trim();
                /**/
                if (texte.Length > 0 && texte.Length <= p_lgMax) break;
                /**/
                WriteLine(
                    "*** Veuillez entrer un texte non vide ayant au maximum {0} caractères.", p_lgMax);
            }

            return texte;
        }

        //-----------------------Bool-----------------------------------

        public static bool ConfirmerOuiOuNon(string p_question)
        {
            char caractèreOuiouNon;

            for (;;)
            {
                Write(p_question);

                if (Char.TryParse(ReadLine(), out caractèreOuiouNon)
                    &&
                    !IsControl(caractèreOuiouNon))
                {
                    if (caractèreOuiouNon == 'O' || caractèreOuiouNon == 'o')
                        return true;
                    else if (caractèreOuiouNon == 'N' || caractèreOuiouNon == 'n')
                        return false;
                }

                WriteLine("*** Veuillez répondre O (pour oui) ou N (pour non), en majuscule ou minuscule.");
            }
        }
    }
}
