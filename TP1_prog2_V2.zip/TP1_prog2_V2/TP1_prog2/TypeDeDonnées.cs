﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP1_prog2
{
    [Serializable]
    public enum TypeDeDéplacements { ContrôleParJoueur, Inerte, ContrôleParIntelligenceArticielle }
    [Serializable]
    public struct Coordonnée
    {
        /// <summary>
        /// coordonnées de la cellule dans le pétri 
        /// </summary>
        /// <param name="p_x">coordonnée en x de la cellule</param>
        /// <param name="p_y">coordonnée en y de la cellule</param>
        public Coordonnée(int p_x, int p_y)
        {
            x = p_x;
            y = p_y;
        }

        public int x;
        public int y;
    }

    [Serializable]
    public class Cellules
    {
        /// <summary>
        ///Les caractéristiques de l'objet Cellule.
        /// </summary>
        /// <param name="p_taille">La taille de la cellule (son diamètre)</param>
        /// <param name="p_coordonnée">la coordonnée en x et en y sous forme (x,y)</param>
        /// <param name="p_typeDeDéplacements">type de déplacement correspondant à la cellule</param>
        /// <param name="p_couleur">couleur attribué à la cellule selon son type de déplacement</param>
        public Cellules(int p_taille, Coordonnée p_coordonnée, TypeDeDéplacements p_typeDeDéplacements, string p_couleur)
        {
            Taille = p_taille;
            Déplacement = p_typeDeDéplacements;
            Coordonnée = p_coordonnée;
            Couleur = p_couleur;
        }
        
        public int Taille { get; set; }
        public Coordonnée Coordonnée { get; set; }
        public TypeDeDéplacements Déplacement { get; set; }
        public string Couleur { get; set; }
    }   
}
