﻿/*  Ce programme est un jeu inspiré de Agar.io ou une cellule doit manger de plus petite cellule pour grossir.
 *  Pour gagner, le joueur doit être la dernière cellule en vie 
 *  et ne pas ce faire manger pour les m_cellules contrôlées par IA.
 Auteur : Samuel Benjamin Chouinard, Kevin Breault
 Date de création : 17/01/27
 Dernière mise à jour : 17/02/25*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using static System.String;
using static System.Console;
using static System.Convert;
using static Utilitaires.Util;

namespace TP1_prog2
{
    class Program : NetProcessing.Sketch
    {
        const string NomFichierDonné = "Cellules.données";  //Nom du fichier de sérialisation des cellules et des dimensions du pétri
        //Dimension par défaut du pétri :
        const int LargeurPétriParDéfaut = 800;
        const int HauteurPétriParDéfaut = 600;
        //Dimension maximum du pétri :
        const int LargeurPétriMax = 1920;
        const int HauteurPétriMax = 1200;
        const string Rouge = "#FF0000"; //Couleur de la cellule joueur
        const string Vert = "#00FF00";  //Couleur des cellules inerte
        const string Bleu = "#0000FF";  //Couleur des cellules contrôlées par IA

        static void Main()
        {
            new Program().Principale();
        }

        List<Cellules> m_cellules;  //Liste des cellules joueur, inertes et contrôlées par l'IA.
        //Dimension du pétri :
        int m_largeurPétri;
        int m_hauteurPétri;
        /// <summary>
        /// Méthode qui récupère les données de la liste des cellules et les dimensions du pétri.
        /// </summary>
        /// <returns></returns>
        bool Récupérer()
        {
            if (!File.Exists(NomFichierDonné))
            {
                m_cellules = new List<Cellules>();
                m_largeurPétri = LargeurPétriParDéfaut;
                m_hauteurPétri = HauteurPétriParDéfaut;
                return false;
            }

            using (FileStream ficDonnées = File.OpenRead(NomFichierDonné))
            {
                BinaryFormatter formateur = new BinaryFormatter();
                m_cellules = (List<Cellules>)formateur.Deserialize(ficDonnées);
                m_largeurPétri = (int)formateur.Deserialize(ficDonnées);
                m_hauteurPétri = (int)formateur.Deserialize(ficDonnées);
            }

            return true;
        }
        /// <summary>
        /// Méthode qui enregistre la liste des cellules et les dimensions du pétri.
        /// </summary>
        void Enregistrer()
        {
            using (FileStream ficDonnées = File.Create(NomFichierDonné))
            {
                BinaryFormatter formateur = new BinaryFormatter();
                formateur.Serialize(ficDonnées, m_cellules);
                formateur.Serialize(ficDonnées, m_largeurPétri);
                formateur.Serialize(ficDonnées, m_hauteurPétri);
            }
        }
        /// <summary>
        /// Ce programme est un jeu inspiré de Agar.io ou une cellule doit manger de plus petite cellule pour grossir.
        /// Pour gagner, le joueur doit être la dernière cellule en vie 
        /// et ne pas ce faire manger pour les m_cellules contrôlées par IA.
        /// </summary>
        void Principale()
        {
            Récupérer();
            int codeOpération;  //Permet à l'utilisateur de naviguer dans le menu.
            string messageAucuneCelluleJoueur;  //Affiche un message dans le menu principal si aucune cellule joueur est présent.

            do
            {
                if (!m_cellules.Any(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur))
                    messageAucuneCelluleJoueur = "(aucune cellule joueur)";
                else
                    messageAucuneCelluleJoueur = "";

                codeOpération = LireInt32DansIntervalle(
                    Format(
                "\nMenu Principal\n" +
                "1-Définir la taille du pétri(actuellement {0} par {1}).\n" +
                "2-Ajouter des cellules(actuellement {2} cellule).\n" +
                "3-Enregistrer les changements et démarrer le jeu{3}\n" +
                "0-Quitter(sans enregistrer)\n" +
                "Choix : ",
                m_largeurPétri, m_hauteurPétri, m_cellules.Count, messageAucuneCelluleJoueur), 0, 3);

                switch (codeOpération)
                {
                    case 1: DéfinirPétri(); break;
                    case 2: AjouterCellule(); break;
                    case 3: Enregistrer(); Start(); break;
                    default: break;
                }
                Clear();
            } while (codeOpération != 3 && codeOpération != 0);
        }
        /// <summary>
        /// Méthode qui permet l'animation du jeu. Elle est appelée 60 fois par seconde.
        /// </summary>
        public override void Draw()
        {
            Background(255, 255, 255);
            DessinerCellules();
            bool celluleJoueurMangé;    //booléen qui confirme si le joueur est vivant(false) ou mangé(true).

            foreach (Cellules c1 in m_cellules)
                DéplacerCellules(c1, DéterminerCibleDesCellulesIA(c1));

            MangerCellule(out celluleJoueurMangé);
            AfficherMessageÉcran(celluleJoueurMangé);
        }
        /// <summary>
        /// Méthode qui compare le rayon de la première cellule(c1) et le centre de la deuxième cellule(c2).
        /// </summary>
        /// <param name="c1">Première cellule à comparer</param>
        /// <param name="c2">deuxième cellule à comparer</param>
        /// <returns>retourne si il y a contacte entre les deux cellules</returns>
        bool ValiderImpact(Cellules c1, Cellules c2)
        {
            return c1.Coordonnée.x + c1.Taille / 2 >= c2.Coordonnée.x
                && c1.Coordonnée.x - c1.Taille / 2 <= c2.Coordonnée.x
                && c1.Coordonnée.y + c1.Taille / 2 >= c2.Coordonnée.y
                && c1.Coordonnée.y - c1.Taille / 2 <= c2.Coordonnée.y;
        }
        /// <summary>
        /// Méthode qui détermine à l'impact de deux cellules quelle sera mangé. 
        /// La cellule de plus grande taille mange l'autre et ajoute la taille de la cellule mangé à la cellule mangeur.
        /// Tandis que la cellule mangé disparais.
        /// </summary>
        void MangerCellule(out bool celluleJoueurMangé)
        {
            List<int> indexCellulesManger = new List<int>();    //Liste des index des cellules mangées

            for (int i = 0; i < m_cellules.Count; i++)
            {
                if (m_cellules[i].Déplacement == TypeDeDéplacements.ContrôleParJoueur
                    || m_cellules[i].Déplacement == TypeDeDéplacements.ContrôleParIntelligenceArticielle)
                {
                    for (int j = 0; j < m_cellules.Count; j++)
                    {
                        if (ValiderImpact(m_cellules[i], m_cellules[j])
                            && m_cellules[i].Taille > m_cellules[j].Taille
                            && !(indexCellulesManger.Any(x => x == j)))
                        {
                            m_cellules[i] = new Cellules(
                                m_cellules[i].Taille + m_cellules[j].Taille,
                                m_cellules[i].Coordonnée,
                                m_cellules[i].Déplacement,
                                m_cellules[i].Couleur);
                            indexCellulesManger.Add(j);
                        }
                    }
                }
            }
            //Vérification si la cellule du joueur a été mangé :
            int indexCelluleJoueur = m_cellules.FindIndex(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur);
            celluleJoueurMangé = false;

            if (indexCellulesManger.Any(x => x == indexCelluleJoueur))
                celluleJoueurMangé = true;
            //Les cellules mangées sont enlevés de la liste des cellules :
            foreach (int index in indexCellulesManger)
                m_cellules.RemoveAtSansOrdre(index);
        }
        /// <summary>
        /// Méthode qui fait l'affichage du message à fin de la partie, que vous soyez gagnant ou perdant.
        /// </summary>
        void AfficherMessageÉcran(bool p_celluleJoueurMangé)
        {
            int indexCelluleJoueur = m_cellules.FindIndex(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur);

            if (p_celluleJoueurMangé)
            {
                NoLoop();
                TextAlign(CENTER);
                Text("DÉFAITE!", m_largeurPétri / 2, m_hauteurPétri / 2);
            }
            else if (m_cellules.All(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur))
            {
                NoLoop();
                TextAlign(CENTER);
                Text("VICTOIRE!", m_largeurPétri / 2, m_hauteurPétri / 2);
            }
        }
        /// <summary>
        /// Méthode qui utilise la liste des cellules et qui les dessine au début de la partie.
        /// </summary>
        void DessinerCellules()
        {
            foreach (Cellules cellule in m_cellules)
            {
                Fill(cellule.Couleur);
                Ellipse(cellule.Coordonnée.x, cellule.Coordonnée.y, cellule.Taille, cellule.Taille);
            }
        }
        /// <summary>
        /// Méthode qui contrôle le déplacement des cellules
        /// </summary>
        /// <param name="c1">cellule 1</param>
        /// <param name="c2">cellule cible pour cellule IA</param>
        void DéplacerCellules(Cellules c1, Cellules c2)
        {
            Coordonnée destination = c1.Coordonnée; //destination de la cellule 1

            if (c1.Déplacement == TypeDeDéplacements.ContrôleParJoueur)
                destination = new Coordonnée(MouseX, MouseY);
            else if (c1.Déplacement == TypeDeDéplacements.ContrôleParIntelligenceArticielle && c1 != c2)
                destination = new Coordonnée(c2.Coordonnée.x, c2.Coordonnée.y);

            if (destination.x != c1.Coordonnée.x && destination.y != c1.Coordonnée.y)
            {
                double angleRadian = Atan2(destination.y - c1.Coordonnée.y, destination.x - c1.Coordonnée.x);
                c1.Coordonnée = new Coordonnée(
                    Round(c1.Coordonnée.x + Cos(angleRadian)),
                    Round(c1.Coordonnée.y + Sin(angleRadian)));
            }
        }
        /// <summary>
        /// Méthode qui détermine la cible des cellules contrôlées par une intelligence artificielle.
        /// </summary>
        /// <param name="c1">cellule 1</param>
        /// <returns>cellule cible</returns>
        Cellules DéterminerCibleDesCellulesIA(Cellules c1)
        {
            Cellules celluleCible = new Cellules(c1.Taille, c1.Coordonnée, c1.Déplacement, c1.Couleur);
            double distancePlusCourt = Sqrt(Pow(m_hauteurPétri, 2) + Pow(m_hauteurPétri, 2));

            foreach (Cellules c2 in m_cellules)
            {
                double distance = CalculerDistance(c1, c2);

                if (c1.Taille > c2.Taille
                    && distance < distancePlusCourt)
                {
                    celluleCible = c2;
                    distancePlusCourt = distance;
                }
            }
            return celluleCible;
        }
        /// <summary>
        /// Calcule la distance entre 2 cellules
        /// </summary>
        /// <param name="c1">cellule 1</param>
        /// <param name="c2">cellule 2</param>
        /// <returns>distance entre c1 et c2</returns>
        double CalculerDistance(Cellules c1, Cellules c2)
        {
            return Sqrt(Pow(c2.Coordonnée.x - c1.Coordonnée.x, 2) + Pow(c2.Coordonnée.y - c1.Coordonnée.y, 2));
        }
        /// <summary>
        /// Défini la taille du pétri avant de commencer le jeu.
        /// </summary>
        public override void Setup()
        {
            base.Setup();
            Size(m_largeurPétri, m_hauteurPétri);
        }
        /// <summary>
        /// Permet à l'utilisateur de changer les dimensions du pétri.
        /// </summary>
        void DéfinirPétri()
        {
            m_largeurPétri = LireInt32DansIntervalle("Largeur du canevas : ", LargeurPétriParDéfaut, LargeurPétriMax);
            m_hauteurPétri = LireInt32DansIntervalle("Hauteur du canevas : ", HauteurPétriParDéfaut, HauteurPétriMax);
        }
        /// <summary>
        /// Permet à l'utilisateur d'ajouter des cellules dans la liste des cellules.
        /// </summary>
        void AjouterCellule()
        {
            int nbCellules = LireInt32DansIntervalle("\nNombre de cellules à ajouter : ", 0, 50);

            for (int i = 0; i != nbCellules; i++)
            {
                char codeOpération;
                TypeDeDéplacements déplacement = TypeDeDéplacements.Inerte;

                for (;;)
                {
                    for (;;)
                    {
                        codeOpération = LireChar(Format(
                        "\nCellule {0}\n" +
                        "Type de déplacement de la cellule :\n" +
                        "--Contrôler par [J]oueur\n" +
                        "--[I]nerte\n" +
                        "--Contrôler par intelligence [A]rtificielle\n" +
                        "Choix : ", i + 1));
                        /**/
                        if (!((codeOpération == 'J' || codeOpération == 'j')
                            &&
                            m_cellules.Any(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur))) break;
                        /**/
                        WriteLine("\n***Il ne peut avoir qu'une cellule contrôlé par le joueur***\n");
                    }

                    bool caratèreEstValide = true;

                    switch (codeOpération)
                    {
                        case 'j':
                        case 'J': déplacement = TypeDeDéplacements.ContrôleParJoueur; break;
                        case 'i':
                        case 'I': déplacement = TypeDeDéplacements.Inerte; break;
                        case 'a':
                        case 'A': déplacement = TypeDeDéplacements.ContrôleParIntelligenceArticielle; break;
                        default: caratèreEstValide = false; break;
                    }
                    /**/
                    if (caratèreEstValide) break;
                    /**/
                    WriteLine("\n***Caractère Non Valide***\n");
                }

                bool confirmationCelluleTailleDouble;
                int taille;

                do
                {
                    taille = LireInt32DansIntervalle("\nTaille de la cellule : ", 1, 100);
                    int indexCelluleJoueur = m_cellules.FindIndex(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur);

                    if (indexCelluleJoueur != -1 && taille > m_cellules[indexCelluleJoueur].Taille * 2)
                    {
                        confirmationCelluleTailleDouble = ConfirmerOuiOuNon(
                            "\nÊtes-vous sûre de vouloir créer une cellule 2 fois plus grande que la vôtre?([O]ui/[N]on) : ");
                    }
                    else
                        confirmationCelluleTailleDouble = true;
                } while (!confirmationCelluleTailleDouble);

                string couleur = "";

                switch (déplacement)
                {
                    case TypeDeDéplacements.ContrôleParJoueur: couleur = Rouge; break;
                    case TypeDeDéplacements.Inerte: couleur = Vert; break;
                    case TypeDeDéplacements.ContrôleParIntelligenceArticielle: couleur = Bleu; break;
                    default: break;
                }

                Coordonnée coordonnée = new Coordonnée(0, 0);
                m_cellules.Add(new Cellules(taille, coordonnée, déplacement, couleur));
                CréerCoordonnéesCellule();

                if (i == nbCellules - 1 && !m_cellules.Any(x => x.Déplacement == TypeDeDéplacements.ContrôleParJoueur))
                {
                    if (!ConfirmerOuiOuNon("\nVous n'avez pas votre propre cellule. Voulez-vous continuer?([O]ui/[N]on) : "))
                        nbCellules++;
                }
            }
        }
        /// <summary>
        /// Créer les coordonnées de la cellule au hasard en vérifiant 
        /// qu'elle n'est pas en collision avec une autre cellule. 
        /// </summary>
        void CréerCoordonnéesCellule()
        {
            int i = m_cellules.Count - 1;
            for (int j = 0; j < m_cellules.Count; ++j)
            {
                for (;;)
                {
                    m_cellules[i].Coordonnée = new Coordonnée(
                        Round(Random(ToDouble(m_largeurPétri - m_cellules[i].Taille))),
                        Round(Random(ToDouble(m_hauteurPétri - m_cellules[i].Taille))));
                    if (i == j
                        || !ValiderImpact(m_cellules[i], m_cellules[j])
                        && m_cellules[i].Coordonnée.x - m_cellules[i].Taille > 0
                        && m_cellules[i].Coordonnée.y - m_cellules[i].Taille > 0) break;
                }
            }
        }
    }
}
